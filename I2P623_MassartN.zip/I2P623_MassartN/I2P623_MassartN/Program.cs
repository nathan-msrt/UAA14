﻿// See https://aka.ms/new-console-template for more information

namespace I2P623_MassartN
{
    class Program
    {
        static void Main(string[] args) {
            Console.WriteLine("Feu de signalisation");
            Console.WriteLine("Etat des feux :");
            Console.WriteLine("-----------------");




            Console.WriteLine("Changement d'état :");
            Console.WriteLine("-----------------");




            Console.WriteLine("Feu clignotant :");
            Console.WriteLine("-----------------");
        }

    }
}